﻿from pathlib import Path
import hashlib,json,shutil,subprocess,traceback,datetime
from urllib.request import Request,urlopen
D=Path(__file__).resolve().parent
M=D.parent/'mobile-monitor/refactor/模型评测/评审专用'
def ctl(*args):
    c=subprocess.run([D/'bin/syncctl.exe',*args,'--root',root],capture_output=True,timeout=40)
    record(['ctl',args,c.stdout.decode('utf8','replace'),c.returncode])
    c.check_returncode()
def record(obj):
    with (out/'trace.jsonl').open('a',encoding='utf8') as f:f.write(json.dumps([datetime.datetime.now().isoformat(),obj],ensure_ascii=False)+'\n')
def api(port,path,body=None):
    req=Request('http://127.0.0.1:'+str(port)+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'})
    with urlopen(req,timeout=30) as r:v=json.load(r)
    record([port,path,body,v])
    return v
def check(name,ok):
    record([name,bool(ok)])
    if not ok:raise AssertionError(name)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def converge():ctl('converge','--timeout','30')
def h1():
    shutil.copytree(M.parent/'参测材料/示例项目',a,dirs_exist_ok=True)
    converge()
    x=b/'data/readings.txt'
    check('baseline',sha(x)==sha(a/'data/readings.txt')=='748a88ea78f384b2d39609fcc0c327f871e52a203b4b93066595aaf158a6ada3')
    api(8732,'/pause',{})
    with x.open('ab') as f:f.write(b'31\n')
    api(8732,'/sync',{})
    wanted='5e0bcdd059a560fb5cee284124be5d22891e6e184c3b4e0b37c9c7ca869983ed'
    check('offline edit',sha(x)==wanted)
    (a/'data/readings.txt').unlink()
    api(8731,'/sync',{});ctl('serverlog','--limit','10');api(8732,'/resume',{});converge()
    for rnd in range(2):
        if rnd:ctl('kill','b');ctl('start','b');converge()
        cs=api(8732,'/conflicts')
        markers=list(x.parent.glob('readings.txt.deleted-by-*.json'))
        record([m.read_text() for m in markers])
        check('edit and delete intent',sha(x)==wanted and cs['conflicts'] and any(json.loads(m.read_text())['deleted_by']=='A' for m in markers))
def h2():
    file=M/'隐藏事件.jsonl'; expected=json.loads((M/'预期历史.json').read_text('utf-8-sig'))
    def dump(final):
        th=api(8732,'/dump?thread=thread-ledger&turn=turn-07&format=json')['threads'][0]; turn=th['turns'][0]; items=turn['items']
        check('identity',th['thread_id']==expected['thread_id'] and turn['turn_id']==expected['turn_id'] and len(items)==4)
        for item,ref in zip(items,expected['items']):
            for k,v in ref.items():
                if k=='type':check('type',item['kind']=={'user.message':'user','tool.call':'tool_call','tool.result':'tool_result','assistant':'assistant'}[v])
                elif k=='status':check('done',item['done']==final)
                else:check(k,item[k]==('哈' if k=='text' and item['kind']=='assistant' and not final else v))
    api(8731,'/import',{'file':str(file),'from':1,'to':4});converge();dump(False)
    api(8732,'/pause',{});api(8731,'/import',{'file':str(file),'from':3,'to':7});api(8731,'/sync',{});api(8732,'/resume',{});converge();dump(True)
    api(8731,'/import',{'file':str(file)});converge();dump(True);ctl('kill','b');ctl('start','b');dump(True)
    check('zero dispatch',api(8732,'/replay',{'thread':'thread-ledger','turn':'turn-07'})['tools_dispatched']==0 and not list(root.rglob('replayed.txt')))
def h3():
    ctl('fault','arm','--mode','commit-ack','--target','A','--count','1')
    rel='notes/receipt.txt';(a/'notes').mkdir();(a/rel).write_bytes(b'sample-42\n')
    rep=api(8731,'/sync',{}); check('lost',rep['receipt_lost'] and rep['pending_push']==1)
    check('persisted',api(8730,'/v1/status')['commit_count']==1);ctl('serverlog')
    for role in ('a','b','server'):ctl('kill',role)
    for role in ('server','b','a'):
        ctl('start',role)
        if role=='server':ctl('serverlog');check('recovered',api(8730,'/v1/status')['commit_count']==1)
    converge()
    for rnd in range(2):
        if rnd:
            for role in ('a','b'):ctl('kill',role);ctl('start',role)
        s=api(8730,'/v1/status');record(api(8731,'/status'))
        check('single commit',s['commit_count']==s['version']==1 and s['dup_hits']>=1)
        check('bytes',sha(a/rel)==sha(b/rel)=='1984ce680995c0b0e46432d070ab1307df43324309f4dd6252a0b9632939fcd2')
        check('queue',not json.loads((root/'a-state/snapshot.json').read_bytes())['pending_batches'])
for fn in (h1,h2,h3):
    out=D/'hidden'/fn.__name__;out.mkdir(parents=True);root=out/'run';a=root/'project-a';b=root/'project-b'
    try:ctl('up');fn();print(fn.__name__,'PASS')
    except Exception:traceback.print_exc()
    finally:ctl('down')
